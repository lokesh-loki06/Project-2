from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys


# noinspection PyUnreachableCode
class test_orange:
   
    def test_setup(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(10)

        # Defining url
        url_orange = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # open the webpage
        driver.get(url_orange)
        time.sleep(3)
        
        # maximize the window
        driver.maximize_window()
        time.sleep(2)

        # Finding username tab Xpath and send key
        xpath_username = '//input[@name="username"]'
        username = driver.find_element(By.XPATH, xpath_username)
        username.send_keys("Admin")

        # Finding password tab Xpath and send key
        xpath_password = '//input[@type="password"]'
        password = driver.find_element(By.XPATH, xpath_password)
        password.send_keys("admin123")

        # click the Login icon
        xpath_login_tab = '//button[@type="submit"]'
        login_tab = driver.find_element(By.XPATH, xpath_login_tab)
        login_tab.click()

        # search "PIM" in serch box
        xpath_search_tab = "//input[@placeholder='Search']"
        search = driver.find_element(By.XPATH, xpath_search_tab).send_keys("PIM")
        PIM = driver.find_element(By.XPATH, "//a[@href='/web/index.php/pim/viewPimModule']")
        PIM.click()
        time.sleep(2)

        # click add button
        xpath_add_button = "//button[normalize-space()='Add']"
        Add = driver.find_element(By.XPATH, xpath_add_button)
        Add.click()

        # First Name
        xpath_firstname = "//input[@placeholder='First Name']"
        firstname = driver.find_element(By.XPATH, xpath_firstname)
        firstname.send_keys("Abdul")

        # middle Name
        xpath_middlename = "//input[@placeholder='Middle Name']"
        middlename = driver.find_element(By.XPATH, xpath_middlename)
        middlename.send_keys("kadhar")

        # last Name
        xpath_lastname = "//input[@placeholder='Last Name']"
        lastname = driver.find_element(By.XPATH, xpath_lastname)
        lastname.send_keys("jeelani")

        # Toggle (create login Details)
        xpath_toggle_button = "//input[@type='checkbox']/following::span[1]"
        toggle = driver.find_element(By.XPATH, xpath_toggle_button)
        toggle.click()
        time.sleep(3)

        # creating user name & passwords
        xpath_Username_login = "(//input[@class='oxd-input oxd-input--active'])[3]"
        login_name = driver.find_element(By.XPATH, xpath_Username_login)
        login_name.send_keys("AbdulKadhalkP")

        xpath_password_login = "(//input[@type='password'])[1]"
        password_user = driver.find_element(By.XPATH, xpath_password_login)
        password_user.send_keys("AbdulKadhar007#")

        xpath_confirm_password_login = "(//input[@type='password'])[2]"
        confirm_password_user = driver.find_element(By.XPATH, xpath_confirm_password_login)
        confirm_password_user.send_keys("AbdulKadhar007#")
        time.sleep(3)

        # hit save
        driver.find_element(By.XPATH,"//button[@type='submit']").click()
        time.sleep(5)


        # closing the wedriver
        driver.close()
        print("Test Completed - user saved")

go = test_orange()
go.test_setup()