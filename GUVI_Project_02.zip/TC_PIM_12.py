from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys


# noinspection PyUnreachableCode
class test_orange:
   
    def test_setup(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(10)

        # Defining url
        url_orange = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # open the webpage
        driver.get(url_orange)
        time.sleep(3)
        
        # maximize the window
        driver.maximize_window()
        time.sleep(2)

        # Finding username tab Xpath and send key
        xpath_username = '//input[@name="username"]'
        username = driver.find_element(By.XPATH, xpath_username)
        username.send_keys("Admin")

        # Finding password tab Xpath and send key
        xpath_password = '//input[@type="password"]'
        password = driver.find_element(By.XPATH, xpath_password)
        password.send_keys("admin123")

        # click the Login icon
        xpath_login_tab = '//button[@type="submit"]'
        login_tab = driver.find_element(By.XPATH, xpath_login_tab)
        login_tab.click()

        # search "PIM" in serch box
        xpath_search_tab = "//input[@placeholder='Search']"
        search = driver.find_element(By.XPATH, xpath_search_tab)
        search.send_keys("PIM")
        PIM = driver.find_element(By.XPATH, "//a[@href='/web/index.php/pim/viewPimModule']")
        PIM.click()
        time.sleep(2)

        # go to post user creation in PIM 
        emplyeelsit = driver.find_element(By.XPATH,"//div[@class='oxd-table-body']//div[@class='oxd-table-cell oxd-padding-cell']/div[.='Abdul kadhar']")
        emplyeelsit.click()
        time.sleep(2)

        # Click Salary tab
        salary_tab = driver.find_element(By.XPATH, "(//a[normalize-space()='Salary'])[1]")
        salary_tab.click()
        time.sleep(2)

        # click add
        add_button = driver.find_element(By.XPATH, "(//button[@type='button'][normalize-space()='Add'])[1]")
        add_button.click()

        # Salary Component
        Salary_component = driver.find_element(By.XPATH, "//form[@class='oxd-form']//div[@class='oxd-grid-3 orangehrm-full-width-grid']/div[1]//input[@class='oxd-input oxd-input--active']")
        Salary_component.send_keys("Salary")

        # Pay Grade
        Grade_box = driver.find_element(By.XPATH, "(//div[@class='oxd-select-text-input'][normalize-space()='-- Select --'])[1]")
        Grade_box.click()

        Grade = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[1]/div/div[2]/div/div[2]/div/div[2]/div[6]/span')
        Grade.click()
        time.sleep(2)

        # Pay Frequency
        Pay_Frequency_box = driver.find_element(By.XPATH, "//form[@class='oxd-form']//div[3]//div[@class='oxd-select-text-input']")
        Pay_Frequency_box.click()

        Pay_Frequency = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[1]/div/div[3]/div/div[2]/div/div[2]/div[4]/span')
        Pay_Frequency.click()
        time.sleep(2)

        # Currency
        action = ActionChains(driver)
        Currency = driver.find_element(By.XPATH, '//label[text()="Currency"]/following::div[text()="-- Select --"]')
        Currency.click()
        action.move_to_element(Currency).send_keys(Keys.ARROW_DOWN).click().perform()

        # Amount
        Amount = driver.find_element(By.XPATH, "//form[@class='oxd-form']//div[5]//input[@class='oxd-input oxd-input--active']")
        Amount.send_keys("40000")

        # toggle direct deposite details
        Toggle_button = driver.find_element(By.XPATH, "//span[@class='oxd-switch-input oxd-switch-input--active --label-right']")
        Toggle_button.click()
        time.sleep(1)

        # Account Number
        Account_Number = driver.find_element(By.XPATH, "(//input[@class='oxd-input oxd-input--active'])[4]")
        Account_Number.send_keys("344275244")

        # Account Type
        Account_Type = driver.find_element(By.XPATH, "//form[@class='oxd-form']/div[4]//div[@class='oxd-select-text-input']")
        Account_Type.click()

        Account_Type_s = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[4]/div[1]/div[2]/div/div[2]/div/div[2]/div[2]/span')
        Account_Type_s.click()
        time.sleep(1)

        # Routing Number
        Routing_number = driver.find_element(By.XPATH, "(//input[@class='oxd-input oxd-input--active'])[5]")
        Routing_number.send_keys("6446")

        # Amount
        Amount = driver.find_element(By.XPATH, "//form[@class='oxd-form']//div[@class='oxd-grid-3 orangehrm-full-width-grid']/div[2]//input[@class='oxd-input oxd-input--active']")
        Amount.send_keys("40000")

        # save
        save = driver.find_element(By.XPATH, "//button[normalize-space()='Save']")
        save.click()
        time.sleep(3)
               

        # Vaidate th saved message popup
        saved_popup = driver.find_element(By.XPATH, "/html/body/script[1]")
        print(saved_popup.is_displayed())
        print(saved_popup.text)

            
        # Validate the successfully saved popup
        if True:
            print("Salary component added successfully")
        else:
            print("failed")
        
        # closing the wedriver
        driver.close()
        print("Test Completed & saved")

go = test_orange()
go.test_setup()