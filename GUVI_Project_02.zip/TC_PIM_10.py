from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys


# noinspection PyUnreachableCode
class test_orange:
   
    def test_setup(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(10)

        # Defining url
        url_orange = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # open the webpage
        driver.get(url_orange)
        time.sleep(3)
        
        # maximize the window
        driver.maximize_window()
        time.sleep(2)

        # Finding username tab Xpath and send key
        xpath_username = '//input[@name="username"]'
        username = driver.find_element(By.XPATH, xpath_username)
        username.send_keys("Admin")

        # Finding password tab Xpath and send key
        xpath_password = '//input[@type="password"]'
        password = driver.find_element(By.XPATH, xpath_password)
        password.send_keys("admin123")

        # click the Login icon
        xpath_login_tab = '//button[@type="submit"]'
        login_tab = driver.find_element(By.XPATH, xpath_login_tab)
        login_tab.click()

        # search "PIM" in serch box
        xpath_search_tab = "//input[@placeholder='Search']"
        search = driver.find_element(By.XPATH, xpath_search_tab)
        search.send_keys("PIM")
        PIM = driver.find_element(By.XPATH, "//a[@href='/web/index.php/pim/viewPimModule']")
        PIM.click()
        time.sleep(4)

        # go to post user creation in PIM 
        emplyeelsit = driver.find_element(By.XPATH,"//div[@class='oxd-table-body']//div[@class='oxd-table-cell oxd-padding-cell']/div[.='Abdul kadhar']")
        emplyeelsit.click()
        time.sleep(3)

        # go to JOb
        job_tab = driver.find_element(By.XPATH,"//a[normalize-space()='Job']")
        job_tab.click()
        time.sleep(3)

        # Terminate Employment
        Terminate_Employment = driver.find_element(By.XPATH, "//button[normalize-space()='Terminate Employment']")
        Terminate_Employment.click()

        # New pop up window 
        # termination date
        termination_date = driver.find_element(By.XPATH, "(//input[@placeholder='yyyy-mm-dd'])[2]")
        termination_date.send_keys("2022-12-07")

        # termination reason
        termination_reason = driver.find_element(By.XPATH, "//div[@class='oxd-sheet oxd-sheet--rounded oxd-sheet--white oxd-dialog-sheet oxd-dialog-sheet--shadow oxd-dialog-sheet--gutters orangehrm-dialog-modal']//div[@class='oxd-select-text-input']")
        termination_reason.click()
        termination_reason.send_keys("l")

        termination_reason_l = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[3]/div/div/div/form/div[2]/div/div[2]/div/div[2]/div[4]/span')
        termination_reason_l.click()

        # termination employment save
        termination_save = driver.find_element(By.XPATH, "//div[@role='document']//button[@type='submit'][normalize-space()='Save']")
        termination_save.click()
        time.sleep(3)

        # validate temination employement saved status
        saved_status = driver.find_element(By.XPATH, "//p[@class='oxd-text oxd-text--p orangehrm-terminate-date']")
        print(saved_status.is_displayed())
        print(saved_status.text)
        time.sleep(3)  

    
        # Validate the successfully saved popup
        if True:
            print("The user job termination successfully completed")
        else:
            print("failed")
        
        # closing the wedriver
        driver.close()
        print("Test Completed & saved")

go = test_orange()
go.test_setup()