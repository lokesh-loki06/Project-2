from selenium import webdriver
import time
from selenium.webdriver.common.by import By

# noinspection PyUnreachableCode
class test_orange:
   
    def test_setup(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(10)

        # Defining url
        url_orange = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # open the webpage
        driver.get(url_orange)
        time.sleep(3)
        
        # maximize the window
        driver.maximize_window()
        time.sleep(3)

        # Finding username tab Xpath and send key
        xpath_username = '//input[@name="username"]'
        username = driver.find_element(By.XPATH, xpath_username)
        username.send_keys("Admin")

        # Finding password tab Xpath and send key
        xpath_password = '//input[@type="password"]'
        password = driver.find_element(By.XPATH, xpath_password)
        password.send_keys("admin123")

        # click the Login icon
        xpath_login_tab = '//button[@type="submit"]'
        login_tab = driver.find_element(By.XPATH, xpath_login_tab)
        login_tab.click()

        # validate the search (Text Box) is displaying on admin Homepage.
        search = driver.find_element(By.XPATH, "//input[@placeholder='Search']")
        print(search.is_displayed())

        # validate the menu options on side pane) are displaying on admin page
        menu = driver.find_element(By.XPATH,"//ul[@class='oxd-main-menu']")
        print(menu.is_displayed())
        print(menu.text)

        # click admin tab using xpath
        # search "Admin" in serch box 
        xpath_search_tab = "//input[@placeholder='Search']"
        search = driver.find_element(By.XPATH, xpath_search_tab).send_keys("admin")
        admin = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        admin.click()

        # go to admin page xpath & Click user under user Management 
        xpath_user_management = "//span[normalize-space()='User Management']"
        User_management = driver.find_element(By.XPATH, xpath_user_management)
        User_management.click()

        xpath_user = "//ul[@class='oxd-dropdown-menu']//li"
        User = driver.find_element(By.XPATH, xpath_user)
        User.click()

        # validate menu are displaying on admin page
        menu = driver.find_element(By.XPATH, "//ul[@class='oxd-main-menu']")
        print(menu.is_displayed())

        # User role validate
        user_Role = driver.find_element(By.XPATH, "(//div[@class='oxd-select-text-input'][normalize-space()='-- Select --'])[1]")
        user_Role.click()
        user_Role_dropdown = driver.find_elements(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[2]/div/div[2]/div/div[2]')
        
        for e in user_Role_dropdown:
            print(e.text)

        # status validate
        status = driver.find_element(By.XPATH, "(//div[@class='oxd-select-text-input'][normalize-space()='-- Select --'])[2]")
        status.click()
        status_dropdown = driver.find_elements(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[4]/div/div[2]/div/div[2]')

        for e in status_dropdown:
            print(e.text)


        # closing the wedriver
        driver.close()
        print("Test Completed - User should be able to see the dropdown values")

go = test_orange()
go.test_setup()