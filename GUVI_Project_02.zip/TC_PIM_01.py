from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys


# noinspection PyUnreachableCode
class test_orange:
   
    def test_setup(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(10)

        # Defining url
        url_orange = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # open the webpage
        driver.get(url_orange)
        time.sleep(3)
        
        # maximize the window
        driver.maximize_window()
        time.sleep(2)

        # Finding username tab Xpath and send key
        xpath_username = '//input[@name="username"]'
        username = driver.find_element(By.XPATH, xpath_username)
        username.send_keys("Admin")

        # Finding password tab Xpath and send key
        xpath_password = '//input[@type="password"]'
        password = driver.find_element(By.XPATH, xpath_password)
        password.send_keys("admin123")

        # click the Login icon
        xpath_login_tab = '//button[@type="submit"]'
        login_tab = driver.find_element(By.XPATH, xpath_login_tab)
        login_tab.click()

        # validate the search (Text Box) is displaying on admin Homepage.
        search = driver.find_element(By.XPATH, "//input[@placeholder='Search']")
        print(search.is_displayed())

        # validate the menu options on side pane) are displaying on admin page
        menu=driver.find_element(By.XPATH,"//ul[@class='oxd-main-menu']")
        print(menu.is_displayed())
        print(menu.text)

        # search "Admin" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("admin")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("ADMIN")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        # search "PIM" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("pim")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("PIM")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        # search "Leave" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("leave")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("LEAVE")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        # search "time" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("time")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("TIME")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()

        # search "Recruitment" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("recruitment")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("RECRUITMENT")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        # search "My Info" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("my info")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("MY INFO")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()

        # search "Performance" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("performance")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("PERFORMANCE")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()

        # search "Dashboard" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("dashboard")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("DASHBOARD")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()

        # search "Directory" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("directory")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("DIRECTORY")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()

        # search "Maintenance" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("maintenance")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("MAINTENANCE")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()

        # search "Buzz" in serch box & validate (both Uppercase and lowercase)
        xpath_search_tab = "//input[@placeholder='Search']"
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("buzz")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        driver.find_element(By.XPATH, xpath_search_tab).send_keys("BUZZ")
        search = driver.find_element(By.XPATH, "//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
        print(search.is_displayed())
        print(search.text)

        # Defining action chain & clear textbox filed
        action = ActionChains(driver)
        action.click(driver.find_element(By.XPATH, xpath_search_tab)).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).send_keys(Keys.BACK_SPACE).perform()
    
        # closing the wedriver
        driver.close()
        print("Test Completed - All individual menu name is dispalyed under search text box.")

go = test_orange()
go.test_setup()
