from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys


# noinspection PyUnreachableCode
class test_orange:
   
    def test_setup(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(10)

        # Defining url
        url_orange = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # open the webpage
        driver.get(url_orange)
        time.sleep(3)
        
        # maximize the window
        driver.maximize_window()
        time.sleep(2)

        # Finding username tab Xpath and send key
        xpath_username = '//input[@name="username"]'
        username = driver.find_element(By.XPATH, xpath_username)
        username.send_keys("Admin")

        # Finding password tab Xpath and send key
        xpath_password = '//input[@type="password"]'
        password = driver.find_element(By.XPATH, xpath_password)
        password.send_keys("admin123")

        # click the Login icon
        xpath_login_tab = '//button[@type="submit"]'
        login_tab = driver.find_element(By.XPATH, xpath_login_tab)
        login_tab.click()

        # search "PIM" in serch box
        xpath_search_tab = "//input[@placeholder='Search']"
        search = driver.find_element(By.XPATH, xpath_search_tab)
        search.send_keys("PIM")
        PIM = driver.find_element(By.XPATH, "//a[@href='/web/index.php/pim/viewPimModule']")
        PIM.click()
        time.sleep(4)

        # go to post user creation in PIM 
        emplyeelsit = driver.find_element(By.XPATH,"//div[@class='oxd-table-body']//div[@class='oxd-table-cell oxd-padding-cell']/div[.='Abdul kadhar']")
        emplyeelsit.click()
        time.sleep(3)

        # Tax Exemptions
        Tax_Exemptions = driver.find_element(By.XPATH, "//a[normalize-space()='Tax Exemptions']")
        Tax_Exemptions.click()

        # Federal Income Tax Status - status
        Status = driver.find_element(By.XPATH, "(//div[@class='oxd-select-text-input'][normalize-space()='-- Select --'])[1]")
        Status.click()
        Status_M = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[1]/div/div[1]/div/div[2]/div/div[2]/div[3]/span')
        Status_M.click()

        # Federal Income Tax Status - exemptions
        exemptions = driver.find_element(By.XPATH, "(//input[@class='oxd-input oxd-input--active'])[2]")
        exemptions.send_keys("99")

        # State Income Tax- state
        state = driver.find_element(By.XPATH, "(//div[contains(text(),'-- Select --')])[1]")
        state.click()
        time.sleep(2)
        state_te = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[2]/div/div[1]/div/div[2]/div/div[2]/div[2]/span')
        state_te.click()

        # State Income Tax - status
        state_Status = driver.find_element(By.XPATH, "//form[@class='oxd-form']//div[@class='oxd-grid-3 orangehrm-full-width-grid']/div[2]//div[@class='oxd-select-text-input']")
        state_Status.click()
        time.sleep(1)
        State_Status_M = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[2]/div/div[2]/div/div[2]/div/div[2]/div[3]/span')
        State_Status_M.click()

        # State Income Tax Status - exemptions
        exemptions = driver.find_element(By.XPATH, "(//input[@class='oxd-input oxd-input--active'])[3]")
        exemptions.send_keys("99")

        # State Income Tax - Unemployment State
        Unemployment_State = driver.find_element(By.XPATH, "//form[@class='oxd-form']//div[4]//div[@class='oxd-select-text-input']")
        Unemployment_State.click()
        time.sleep(1)
        Unemployment_State_t = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[2]/div/div[4]/div/div[2]/div/div[2]/div[25]/span')
        Unemployment_State_t.click()

        # State Income Tax - work State
        work_State = driver.find_element(By.XPATH, "//form[@class='oxd-form']//div[5]//div[@class='oxd-select-text-input']")
        work_State.click()
        time.sleep(1)
        work_State_a = driver.find_element(By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[2]/div/div[5]/div/div[2]/div/div[2]/div[2]/span')
        work_State_a.click()

        # save
        save = driver.find_element(By.XPATH, "//button[normalize-space()='Save']")
        save.click()
        time.sleep(4)


        # Vaidate th saved message popup
        saved_popup = driver.find_element(By.XPATH, "/html/body/script[1]")
        print(saved_popup.is_displayed())
        print(saved_popup.text)

            
        # Validate the successfully saved popup
        if True:
            print("Tax exemptions detials entered successfully")
        else:
            print("failed")
        
        # closing the wedriver
        driver.close()
        print("Test Completed & saved")

go = test_orange()
go.test_setup()