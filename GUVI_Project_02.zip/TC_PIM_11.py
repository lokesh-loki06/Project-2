from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys


# noinspection PyUnreachableCode
class test_orange:
   
    def test_setup(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(10)

        # Defining url
        url_orange = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # open the webpage
        driver.get(url_orange)
        time.sleep(3)
        
        # maximize the window
        driver.maximize_window()
        time.sleep(2)

        # Finding username tab Xpath and send key
        xpath_username = '//input[@name="username"]'
        username = driver.find_element(By.XPATH, xpath_username)
        username.send_keys("Admin")

        # Finding password tab Xpath and send key
        xpath_password = '//input[@type="password"]'
        password = driver.find_element(By.XPATH, xpath_password)
        password.send_keys("admin123")

        # click the Login icon
        xpath_login_tab = '//button[@type="submit"]'
        login_tab = driver.find_element(By.XPATH, xpath_login_tab)
        login_tab.click()

        # search "PIM" in serch box
        xpath_search_tab = "//input[@placeholder='Search']"
        search = driver.find_element(By.XPATH, xpath_search_tab)
        search.send_keys("PIM")
        PIM = driver.find_element(By.XPATH, "//a[@href='/web/index.php/pim/viewPimModule']")
        PIM.click()
        time.sleep(4)

        # go to post user creation in PIM 
        emplyeelsit = driver.find_element(By.XPATH,"//div[@class='oxd-table-body']//div[@class='oxd-table-cell oxd-padding-cell']/div[.='Abdul kadhar']")
        emplyeelsit.click()
        time.sleep(3)

        # go to JOb
        job_tab = driver.find_element(By.XPATH,"//a[normalize-space()='Job']")
        job_tab.click()
        time.sleep(3)

        # Activate Employment
        Activate_Employment = driver.find_element(By.XPATH, "//button[normalize-space()='Activate Employment']")
        Activate_Employment.click()

        # Vaidate th saved message popup
        saved_popup = driver.find_element(By.XPATH, "/html/body/script[1]")
        print(saved_popup.is_displayed())
        print(saved_popup.text)

            
        # Validate the successfully saved popup
        if True:
            print("activate employement successfully")
        else:
            print("failed")
        
        # closing the wedriver
        driver.close()
        print("Test Completed & saved")

go = test_orange()
go.test_setup()