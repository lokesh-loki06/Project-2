from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys


# noinspection PyUnreachableCode
class test_orange:
   
    def test_setup(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(10)

        # Defining url
        url_orange = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # open the webpage
        driver.get(url_orange)
        time.sleep(3)
        
        # maximize the window
        driver.maximize_window()
        time.sleep(2)

        # Finding username tab Xpath and send key
        xpath_username = '//input[@name="username"]'
        username = driver.find_element(By.XPATH, xpath_username)
        username.send_keys("Admin")

        # Finding password tab Xpath and send key
        xpath_password = '//input[@type="password"]'
        password = driver.find_element(By.XPATH, xpath_password)
        password.send_keys("admin123")

        # click the Login icon
        xpath_login_tab = '//button[@type="submit"]'
        login_tab = driver.find_element(By.XPATH, xpath_login_tab)
        login_tab.click()

        # search "PIM" in serch box
        xpath_search_tab = "//input[@placeholder='Search']"
        search = driver.find_element(By.XPATH, xpath_search_tab)
        search.send_keys("PIM")
        
        PIM = driver.find_element(By.XPATH, "//a[@href='/web/index.php/pim/viewPimModule']")
        PIM.click()
        time.sleep(2)

        # go to post user creation in PIM 
        emplyeelsit = driver.find_element(By.XPATH,"//div[@class='oxd-table-body']//div[@class='oxd-table-cell oxd-padding-cell']/div[.='Abdul kadhar']")
        emplyeelsit.click()
        time.sleep(3)

        # go to contact details page
        contact_Details = driver.find_element(By.XPATH,"//a[normalize-space()='Contact Details']")
        contact_Details.click()
        time.sleep(3)

        # go to contact details page
        # street1
        street1 = driver.find_element(By.XPATH,"(//input[@class='oxd-input oxd-input--active'])[2]")
        street1.send_keys("Kutty street")

        # street2
        street2=driver.find_element(By.XPATH,"(//input[@class='oxd-input oxd-input--active'])[3]")
        street2.send_keys("Pereya Pet")

        # city
        city = driver.find_element(By.XPATH,"(//input[@class='oxd-input oxd-input--active'])[4]")
        city.send_keys("Gudiyattam")

        # state
        state = driver.find_element(By.XPATH,"(//input[@class='oxd-input oxd-input--active'])[5]")
        state.send_keys("Tamilnadu")

        # postalcode
        postalcode = driver.find_element(By.XPATH,"(//input[@class='oxd-input oxd-input--active'])[6]")
        postalcode.send_keys("632602")

        # country
        country = driver.find_element(By.XPATH,"//label[text()='Country']/following::div[1]")
        action = ActionChains(driver)
        action.move_to_element(country).click().perform()

        select_country = driver.find_element(By.XPATH,"//div[@class='oxd-select-text-input']")
        ActionChains(driver).move_to_element(select_country).click().perform()
        time.sleep(2)

        # Telephone_home
        Telephone_home = driver.find_element(By.XPATH,"(//input[@class='oxd-input oxd-input--active'])[7]")
        Telephone_home.send_keys("226222")

        Telephone_mobile = driver.find_element(By.XPATH,"//*[@id='app']/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[2]/div/div[2]/div/div[2]/input")
        Telephone_mobile.send_keys("987654321")

        # Telephone_work
        Telephone_work = driver.find_element(By.XPATH,"//div[@class='oxd-input-group__label-wrapper']/following::input[8]")
        Telephone_work.send_keys("789456321")
        time.sleep(3)

        # workemail
        workemail = driver.find_element(By.XPATH,"//div[@class='oxd-input-group__label-wrapper']/following::input[9]")
        workemail.send_keys("abdul@official.com")
        time.sleep(3)

        # othermail
        othermail = driver.find_element(By.XPATH, "//div[3]//div[1]//div[2]//div[1]//div[2]//input[1]")
        othermail.send_keys("abdul@other.com")
        time.sleep(3)

        # save
        save = driver.find_element(By.XPATH,"//button[@type='submit']")
        save.click()
        time.sleep(3)   

        # Validate the successfully saved popup
        if True:
            print("The user is contact details added successfully")
        else:
            print("failed")
        
        # closing the wedriver
        driver.close()
        print("Test Completed - contact saved")

go = test_orange()
go.test_setup()